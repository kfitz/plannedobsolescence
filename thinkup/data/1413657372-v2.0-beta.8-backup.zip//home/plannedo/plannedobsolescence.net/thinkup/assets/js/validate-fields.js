$(function () { $("input").not("[type=submit]").jqBootstrapValidation(); } );
