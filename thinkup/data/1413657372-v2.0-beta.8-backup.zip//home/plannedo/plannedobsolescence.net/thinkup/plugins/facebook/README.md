Facebook ThinkUp Plugin
=========================

The Facebook ThinkUp plugin retrieves posts from Facebook user profiles and Facebook pages.

Installation
------------

For installation instructions, see the Facebook plugin configuration page, while logged in as an admin:

    http://yourserver.com/path-to-thinkup-webapp/account/?p=facebook

Use the same page to authorize the Facebook account(s) ThinkUp should crawl: click the **Connect with Facebook** button first, then use the link beneath it to grant ThinkUp offline access.

Crawler Plugin
--------------

During the crawl process, the Facebook plugin retrieves posts on user profiles and pages and inserts them and their comments into the ThinkUp database.